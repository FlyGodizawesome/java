package dev.danvega.runnerz.user;

public record Geo(
        Double lng,
        Double lat) {
}
