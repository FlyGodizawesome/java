package dev.danvega.runnerz.run;

public enum Location {
    INDOOR,
    OUTDOOR
}
